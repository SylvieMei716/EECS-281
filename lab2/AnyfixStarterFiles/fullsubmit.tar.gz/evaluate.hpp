// Project identifier: 1CAEF3A0FEDD0DEC26BA9808C69D4D22A9962768

#pragma once

#include <string>
#include <cstdint>


auto evaluate(std::string const& expression) -> std::int64_t;
